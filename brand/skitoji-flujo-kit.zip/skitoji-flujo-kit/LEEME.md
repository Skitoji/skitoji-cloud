# SKITOJI — FLUJO / kit de logo

La S elegida en la propuesta 06, preparada como símbolo vectorial y archivos de uso diario.

- **01-vector:** SVG escalables y PDF vectoriales en azul, oscuro y blanco.
- **02-transparent:** PNG cuadrados sin fondo, en 128, 256, 512, 1024, 2048 y 4096 píxeles.
- **03-profile:** avatares cuadrados con fondo claro, oscuro y azul, en 400, 800, 1080 y 2048 píxeles. Incluye SVG y JPG de 1080 px.

## Qué archivo usar

Para la foto de perfil de tus redes, empieza con un PNG **perfil** de 1080 px. El símbolo tiene un margen amplio para los recortes circulares; revisa la vista previa de cada plataforma antes de guardar. Para un diseño sobre una foto o vídeo, usa un PNG **transparent**. Para imprenta, animación o cambios de escala, parte del SVG o PDF.

Todos los archivos se renderizaron directamente desde el vector a su resolución final; no se ampliaron imágenes pequeñas. Los PNG transparentes mantienen alfa. Los avatares son cuadrados, no círculos precortados. Los tamaños son opciones de exportación, no requisitos específicos de plataformas.

## Color y conservación

- Azul: #3049E8. Oscuro: #20231F. Blanco: #FFFFFF. Fondo claro: #F7F7F2.
- Mantén las proporciones. No estires, recortes ni alteres el contorno o los espacios negativos.
- Usa blanco sobre fondos oscuros y azul u oscuro sobre fondos claros.
- No añadas sombras, degradados, bordes ni otros efectos al símbolo.

manifest.json contiene dimensiones, variantes y hashes SHA-256 de todos los gráficos. El símbolo se usa con el nombre SKITOJI en la web, pero los archivos de perfil contienen solo la marca para que se reconozca a tamaños pequeños.
